export interface User {
    id: number;
	name: string;
	type: string;
	email: string;
	password: string;
	blocked:number;
}

export interface Training {
	id:{
		mentor: number;
		technology: string;
		mentee: number;
	};
	name: string;
	status: number;
	finalized: number;
	progress: number;
	rate: number;
	startsAt: number;
	endsAt: number;
}

export interface Technology {
	technology: string;
	active: any;
}

export interface Mentor {
    mentor: number;	
	name: string;
	technology: string;	
	yearsofexperience: number;
	nooftrainingsdelivered: number;
	averagerating: number;
	cost: number;
	payment: number;
}

export interface Timezone {
	timezone: string;
}

export interface Calendar {
	mentor: number;
	timezone: string;
	workingfrom: number;
	workingtill: number;
}