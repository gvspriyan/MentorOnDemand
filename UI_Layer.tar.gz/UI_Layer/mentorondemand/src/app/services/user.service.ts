import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { User,Training, Technology, Mentor, Timezone, Calendar } from './user';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { TrainingsComponent } from '../trainings/trainings.component';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Access-Control-Allow-Origin': '*'    
    //'Authorization': 'my-auth-token'
  })
};

@Injectable({
  providedIn: 'root'
})

export class UserService {

  public activeuser:User
  public activeview:String //search or history or trainings or completed
  
  url = 'http://localhost:8088/'

  constructor(private http: HttpClient) {
    this.activeuser = null
   }

  searchMentors(technology:string, timezone: string, hour: number) {
    return this.http.get<any[]>(this.url + "find-mentors/" + technology + "/" + timezone + "/" + hour)
    .pipe(
      catchError(this.handleError)
    );    
  }

  searchMentorsForTechnology(technology:string, timezone: string, hour: number) {
    return this.http.get<any[]>(this.url + "find-mentors/" + this.activeuser.id + "/" + technology + "/" + timezone + "/" + hour)
    .pipe(
      catchError(this.handleError)
    );    
  }

  searchMenteeTrainings() {
    return this.http.get<any[]>(this.url + "find-mentee/" + this.activeuser.id)
    .pipe(
      catchError(this.handleError)
    );    
  }

  searchMentorCalendar(technology:string) {
    return this.http.get<User[]>(this.url + "find-users")
    .pipe(
      catchError(this.handleError)
    );    
  }

  searchTrainings(technology:string, timezone:string, hour:number) {
    return this.http.get<Mentor[]>(this.url + "find-mentors/" + technology + "/" + timezone + "/" + hour)
    .pipe(
      catchError(this.handleError)
    );    
  }

  searchTechnologies() {
    return this.http.get<Technology[]>(this.url + "find-technologies")
    .pipe(
      catchError(this.handleError)
    );    
  }

  searchTimezones() {
    return this.http.get<Timezone[]>(this.url + "find-timezones")
    .pipe(
      catchError(this.handleError)
    );    
  }

  proposeTraining(mentor:number, technology:string, hour:number) {
    var proposal = {} as Training
    proposal.id = {mentor:mentor, technology:technology, mentee:this.activeuser.id}
    proposal.status = 0 //Proposed
    proposal.finalized = 0 // false - not finalized
    proposal.progress = 0
    proposal.rate = 0 // Not rated
    proposal.startsAt = hour
    proposal.endsAt = Number.parseInt(hour.toString()) + Number.parseInt("2") //Adding two hours

    return this.http.post(this.url + "propose/", proposal)
    .pipe(
      catchError(this.handleError)
    );    
  }

  authenticateUser(email: string, pwd: string) {
    return this.http.get<User>(this.url + "authenticate/" + email + "/" + pwd)
    .pipe(
      catchError(this.handleError)
    );    
  }

  searchMentorHistory() {
    return this.http.get<Training[]>(this.url + "find-history/" + this.activeuser.id)
    .pipe(
      catchError(this.handleError)
    );    
  }

  confirmTraining(mentor:number, technology:string, mentee:number) {
    var confirm = {} as Training
    confirm.id = {mentor:mentor, technology:technology, mentee:mentee}

    return this.http.put(this.url + "confirm/", confirm)
    .pipe(
      catchError(this.handleError)
    );    
  }

  finalizeTraining(mentor:number, technology:string, mentee:number) {
    var finalize = {} as Training
    finalize.id = {mentor:mentor, technology:technology, mentee:mentee}

    return this.http.put(this.url + "finalize/", finalize)
    .pipe(
      catchError(this.handleError)
    );    
  }

  rateTraining(mentor:number, technology:string, mentee:number, rating:number) {
    var rate = {} as Training
    rate.id = {mentor:mentor, technology:technology, mentee:mentee}
    rate.rate = rating

    return this.http.put(this.url + "rate/", rate)
    .pipe(
      catchError(this.handleError)
    );    
  }

  rejectTraining(mentor:number, technology:string, mentee:number) {
    var reject = {} as Training
    reject.id = {mentor:mentor, technology:technology, mentee:mentee}

    return this.http.put(this.url + "reject/", reject)
    .pipe(
      catchError(this.handleError)
    );    
  }

  progress(mentor:number, technology:string, mentee:number, progress:number) {
    var report = {} as Training
    report.id = {mentor:mentor, technology:technology, mentee:mentee}
    report.progress = progress

    return this.http.put(this.url + "progress/", report)
    .pipe(
      catchError(this.handleError)
    );    
  }

  adminUsers() {
    return this.http.get<any[]>(this.url + "admin-users")
    .pipe(
      catchError(this.handleError)
    );    
  }

  adminMentors() {
    return this.http.get<any[]>(this.url + "admin-mentors")
    .pipe(
      catchError(this.handleError)
    );    
  }

  adminTech() {
    return this.http.get<any[]>(this.url + "admin-tech")
    .pipe(
      catchError(this.handleError)
    );    
  }

  block(userId:number) {
    var user = {} as User
    user.id = userId

    return this.http.put(this.url + "admin-users-block/", user)
    .pipe(
      catchError(this.handleError)
    );    
  }

  unblock(userId:number) {
    var user = {} as User
    user.id = userId

    return this.http.put(this.url + "admin-users-unblock/", user)
    .pipe(
      catchError(this.handleError)
    );    
  }

  commission(mentor:number, technology:string, comm:number) {
    var skills = {} as any
    skills.id = {mentor:mentor, technology:technology}
    skills.commission = comm

    return this.http.put(this.url + "commission/", skills)
    .pipe(
      catchError(this.handleError)
    );    
  }
  
  addtechnology(newtech:string) {
    var tech = {} as Technology
    tech.technology = newtech
    tech.active = 1

    return this.http.post(this.url + "add-tech/", tech)
    .pipe(
      catchError(this.handleError)
    );    
  }

  toggletechnology(tech:Technology) {
    return this.http.put(this.url + "toggle-tech/", {technology:tech.technology, active: tech.active? 0: 1})
    .pipe(
      catchError(this.handleError)
    );    
  }

  addUser(user:User) {
    return this.http.post(this.url + "add-user/", user)
    .pipe(
      catchError(this.handleError)
    );    
  }

  addMentor(user:User, calendar: Calendar, skills:Mentor[] ) {
    var mentor:any = {User:user, Calendar:calendar, Mentor:skills}
//    console.log(JSON.stringify(mentor))
    return this.http.post(this.url + "add-mentor/", mentor)
    .pipe(
      catchError(this.handleError)
    );    
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
      'Something bad happened; please try again later.');
  }
}