import { NgModule } from '@angular/core';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { Routes, RouterModule } from '@angular/router';
import { NotificationsComponent } from './notifications/notifications.component';
import { TrainingsComponent } from './trainings/trainings.component';
import { UserGuard } from './guards/user.guard';
import {WelcomeComponent} from './welcome/welcome.component'
import { ResultsComponent } from './results/results.component';
import { SignupComponent } from './signup/signup.component';

const routes:Routes = [
  {path:'welcome', component: WelcomeComponent},
  {path:'results', component: ResultsComponent, canActivate:[UserGuard]},
  //{path:'home', component: HomeComponent},
  {path:'login', component: LoginComponent},
  {path:'signup', component: SignupComponent},
  {path:'notifications', component: NotificationsComponent, canActivate:[UserGuard]},
  {path:'trainings', component: TrainingsComponent},
  //{path:'welcome', component: WelcomeComponent, canActivate:[UserGuard]},
  {path:'**', redirectTo: 'welcome'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
