import { Component, OnInit } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { UserService } from '../services/user.service';
import { Technology, Mentor, Timezone } from '../services/user';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  technologies:Technology[]
  timezones:Timezone[]
  mentors:Mentor[]
  indexchosen:number
  techchosen:string
  tzonechosen:string
  hourchosen:number

  constructor(private userService: UserService, private router: Router) {
    this.technologies = []
    this.timezones = []
 }

  ngOnInit() {
    this.searchTechnologies()
    this.searchTimezones()
    this.selectTime(0,7)
  }

  searchTechnologies() { this.userService.searchTechnologies().subscribe( (techs) => {
    for (let i = 0; i < techs.length; i++) {
      this.technologies.push(techs[i])
    }
    this.techchosen = this.technologies[0].technology
  })}

  searchTimezones() { this.userService.searchTimezones().subscribe( (tzones) => {
    for (let i = 0; i < tzones.length; i++) {
      this.timezones.push(tzones[i])
    }
    this.tzonechosen = this.timezones[0].timezone
  })}

  searchMentors() { this.userService.searchMentors("java",	"Asia/Karachi", 5).subscribe( (mentors) => {
    for (let i = 0; i < mentors.length; i++) {
      this.mentors.push(mentors[i])
    }
  })}

  selectTime(index, hour) {
    this.indexchosen = index
    this.hourchosen = hour
  }

  searchTrainings() {
    let navigationExtras: NavigationExtras = {
      queryParams: {
          "usertype": this.userService.activeuser? "mentee":"guest",
          "technology": this.techchosen,
          "timezone": this.tzonechosen,
          "hour": this.hourchosen
      }
    }
    this.userService.activeview = "Guest"
    this.router.navigate(["results"], navigationExtras);    
  }
}
