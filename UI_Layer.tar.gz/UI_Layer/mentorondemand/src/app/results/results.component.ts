import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../services/user.service';
import { User, Training, Mentor } from '../services/user';
import { Technology } from '../services/user.1';

@Component({
  selector: 'app-results',
  templateUrl: './results.component.html',
  styleUrls: ['./results.component.css']
})
export class ResultsComponent implements OnInit {
  users:User[]
  mentors:Mentor[]
  trainings:Training[]
  technologies: Technology[]
  usertype: string
  techchosen: string
  tzonechosen: string
  anonymous: string
  hourchosen: number
  userview: any[]
  mentorview: any[]
  adminuserview: any[]
  adminmentorview: any[]
  admintechview: any[]
  newtech: string

  constructor(private userService: UserService, private route: ActivatedRoute, private router: Router) {
    this.users = []
    this.trainings = []
    this.mentors = []
    this.userview = []
    this.mentorview = []
    this.adminuserview = []
    this.adminmentorview = []
    this.admintechview = []
    this.technologies = []
    this.route.queryParams.subscribe(params => {
      this.usertype = params["usertype"]
      this.anonymous = params["anonymous"] // such a param never passed
      this.techchosen = params["technology"]
      this.tzonechosen = params["timezone"]
      this.hourchosen = params["hour"]
    })
   }

  ngOnInit() {
    switch(this.usertype) {
      case "guest":
          this.userService.activeview = "Guest"
          this.userService.searchMentors(this.techchosen, this.tzonechosen, this.hourchosen).subscribe( (data) => {
            for (let i = 0; i < data.length; i++) {
              this.userview.push(data[i])
            }
          })
          break;
      case "mentee":
          this.userService.activeview = "Mentee"
          if (this.techchosen) {
            this.userService.searchMentorsForTechnology(this.techchosen, this.tzonechosen, this.hourchosen).subscribe( (data) => {
              for (let i = 0; i < data.length; i++) {
                this.userview.push(data[i])
              }
            })
          } else {
            this.userService.searchMenteeTrainings().subscribe( (data) => {
              for (let i = 0; i < data.length; i++) {
                this.userview.push(data[i])
              }
            })
          }
          break;
      case "mentor":
        this.userService.activeview = "Mentor"        
        this.userService.searchMentorHistory().subscribe( (data) => {
          for (let i = 0; i < data.length; i++) {
            this.mentorview.push(data[i])
          }
        })
        break;
      case "adminuser":
        this.userService.activeview = "AdminUser"
        this.userService.adminUsers().subscribe( (data) => {
          for (let i = 0; i < data.length; i++) {
            this.adminuserview.push(data[i])
          }
        })
        break;
      case "adminmentor":
        this.userService.activeview = "AdminMentor"
        this.userService.adminMentors().subscribe( (data) => {
          for (let i = 0; i < data.length; i++) {
            this.adminmentorview.push(data[i])
          }
        })
        break;
      case "admintech":
        this.userService.activeview = "AdminTech"
        this.userService.searchTechnologies().subscribe( (data) => {
          for (let i = 0; i < data.length; i++) {
            this.technologies.push({technology: data[i].technology, active: data[i].active == 1? true: false})
          }
        })
        break;
      default:
        console.log("warning: results.component doing nothing")
        break; //do nothing
    }
  }

  propose(index:number) { // Mentee proposes
    this.userService.proposeTraining(this.userview[index].mentor, this.userview[index].technology, this.hourchosen).subscribe( () => {
      this.userview[index].status = 'PROPOSED'
    })
  }

  confirm(index:number) { // Mentor confirms
    this.userService.confirmTraining(this.mentorview[index].id.mentor, this.mentorview[index].id.technology, this.mentorview[index].id.mentee).subscribe( () => {
      this.mentorview[index].id.status = 'CONFIRMED'
    })
  }

  finalize(index:number) { // Mentee finalizes
    this.userService.finalizeTraining(this.userview[index].mentor, this.userview[index].technology, this.userview[index].mentee).subscribe( () => {
      this.userview[index].status = 'IN-PROGRESS'
    })
  }

  reject(index:number) { // Mentor rejects
    this.userService.rejectTraining(this.mentorview[index].id.mentor, this.mentorview[index].id.technology, this.mentorview[index].id.mentee).subscribe( () => {
      this.mentorview[index].id.status = 'REJECTED'
    })
  }

  progress(index:number) { // Mentee reports progress
    this.userService.progress(this.userview[index].mentor, this.userview[index].technology, this.userview[index].mentee, this.userview[index].progress).subscribe( () => {
      this.userview[index].status = this.userview[index].progress == 100 ?  'COMPLETED': 'FINALIZED'
    })
  }

  rate(index:number) { // Mentee rates the training
    this.userService.rateTraining(this.userview[index].mentor, this.userview[index].technology, this.userview[index].mentee, this.userview[index].rate).subscribe( () => {
      //Do nothing
    })
  }

  block(index:number) { // Admin blocks a user
    this.userService.block(this.adminuserview[index].id).subscribe( () => {
      this.adminuserview[index].blocked = 1
    })
  }

  unblock(index:number) { // Admin unblocks a user
    this.userService.unblock(this.adminuserview[index].id).subscribe( () => {
      this.adminuserview[index].blocked = 0
    })
  }

  commission(index:number) { // Change commission
    this.userService.commission(this.adminmentorview[index].mentor, this.adminmentorview[index].technology, this.adminmentorview[index].commission).subscribe( () => {
      //Do nothing
    })
  }

  onkeydown(event) {
    if (event.key === "Enter") {
      this.userService.addtechnology(this.newtech).subscribe( (data:Technology) => {
        this.technologies.push(data)
      })
    }
  }

  toggletechnology(index: number) {
    this.userService.toggletechnology(this.technologies[index]).subscribe( () => {
      //Do nothing
    })
  }
}