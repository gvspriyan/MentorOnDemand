import { Injectable } from '@angular/core';
import { UserService } from '../services/user.service';
import { Router, CanActivate } from '@angular/router';

@Injectable({providedIn:'root'})
export class UserGuard implements CanActivate {

    constructor(private router:Router, private userService:UserService){}

    canActivate():boolean{
        if (this.userService.activeview != "Guest" && !this.userService.activeuser) {
            this.router.navigate(['welcome']);
        }

        return true
    }
} 