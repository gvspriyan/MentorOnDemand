import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { User, Mentor, Timezone } from '../services/user';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})

export class NotificationsComponent implements OnInit {

  users:User[]
  mentors:Mentor[]
  timezones:Timezone[]

  constructor(private userService: UserService) { this.users = [] }

  ngOnInit() {
    this.searchMentors()
    this.searchTimezones()
  }

  searchMentors() { this.userService.searchMentors("Java", "Asia/Karachi", 5).subscribe( (mentors) => {
    for (let i = 0; i < mentors.length; i++) {
      this.mentors.push(mentors[i])
    }
  })}

  searchTimezones() { this.userService.searchTimezones().subscribe( (tzones) => {
    for (let i = 0; i < tzones.length; i++) {
      this.timezones.push(tzones[i])
    }
  })}

}