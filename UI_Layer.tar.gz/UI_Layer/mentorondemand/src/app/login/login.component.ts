import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email:string
  pwd:string

  constructor(private userService:UserService, private router:Router) { }

  ngOnInit() {
    //Does the user wants to logout ? If already logged in, then yes
    if (this.userService.activeuser) {
      this.userService.activeuser = null
      this.router.navigate(['welcome']);
    }
  }

  signin(){ this.userService.authenticateUser(this.email, this.pwd).subscribe( (user) => {
    this.userService.activeuser = user
    switch(user.type) {
      case "mentee": this.userService.activeview = "Mentee"; break;
      case "mentor": this.userService.activeview = "Mentor"; break;
      default: this.userService.activeview = "Guest"; break;
    }
    this.router.navigate(['welcome'])
  })}
}