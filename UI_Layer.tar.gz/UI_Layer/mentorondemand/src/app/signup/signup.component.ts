import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { User, Technology, Timezone, Mentor, Calendar } from '../services/user';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  newuser: User
  mentorcalendar: Calendar
  mentorskills: Mentor[]
  technologies:Technology[]
  timezones:Timezone[]
  techchosen: string
  tzonechosen:string
  startindexchosen:number
  endindexchosen:number
  currentindex: number

  constructor(private userService: UserService, private router:Router) {
    this.newuser = <User>{}
    this.mentorcalendar = <Calendar>{}
    this.mentorskills = []
    this.technologies = []
    this.timezones = []
    this.startindexchosen = 14
    this.endindexchosen = 0
    this.mentorcalendar.workingfrom = 21
    this.mentorcalendar.workingtill = 0
    this.currentindex = 0
  }

  ngOnInit() {
    this.newuser.type = 'mentee'

    this.userService.searchTechnologies().subscribe( (techs) => {
      for (let i = 0; i < techs.length; i++) {
        this.technologies.push(techs[i])
        this.mentorskills[i] = <Mentor>{}
        this.mentorskills[i].technology = this.technologies[i].technology
        this.mentorskills[i].cost = 0
      }
      this.techchosen = this.technologies[0].technology
    })

    this.userService.searchTimezones().subscribe( (tzones) => {
      for (let i = 0; i < tzones.length; i++) {
        this.timezones.push(tzones[i])
      }
      this.tzonechosen = this.timezones[0].timezone
    })    
  }

  handleradio(type: string) {
    this.newuser.type = type
  }

  submit() {
    this.newuser.blocked = 0
    if (this.newuser.type == 'mentee') {
      this.userService.addUser(this.newuser).subscribe(() => {
          //Do nothing
      })
    }
    else {
      this.userService.addMentor(this.newuser, this.mentorcalendar, this.mentorskills).subscribe(() => {
        //Do nothing
    })
    }
    this.router.navigate(['welcome']);
  }

  cancel() {
    this.router.navigate(['welcome']);
  }

  selectTime(index, hour) {
    if (index < this.startindexchosen) this.startindexchosen = index
    if (index > this.endindexchosen)   this.endindexchosen = index
    if (index > this.startindexchosen && index < this.endindexchosen ) this.startindexchosen = this.endindexchosen = index
    if (hour < this.mentorcalendar.workingfrom) this.mentorcalendar.workingfrom = hour
    if (hour > this.mentorcalendar.workingtill) this.mentorcalendar.workingtill = hour
    if (hour > this.mentorcalendar.workingfrom && hour < this.mentorcalendar.workingtill) this.mentorcalendar.workingfrom = this.mentorcalendar.workingtill = hour
  }

  setcurrentindex(i) {
    this.currentindex = i
  }
}