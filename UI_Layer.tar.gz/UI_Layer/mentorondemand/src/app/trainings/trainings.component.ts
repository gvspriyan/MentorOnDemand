import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { User, Training, Mentor } from '../services/user';

@Component({
  selector: 'app-trainings',
  templateUrl: './trainings.component.html',
  styleUrls: ['./trainings.component.css']
})
export class TrainingsComponent implements OnInit {

  users:User[]
  mentors:Mentor[]
  trainings:Training[]

  constructor(private userService: UserService) {
    this.users = []
    this.trainings = []
  }

  ngOnInit() {
  }

  currentTrainings() { this.userService.searchMentors("Java", "Asia/Karachi", 5).subscribe( (mentors) => {
    for (let i = 0; i < mentors.length; i++) {
      this.mentors.push(mentors[i])
    }
  })}

  completedTrainings() { this.userService.searchMentors("Java", "Asia/Karachi", 5).subscribe( (mentors) => {
    for (let i = 0; i < mentors.length; i++) {
      this.mentors.push(mentors[i])
    }
  })}
}