Full Stack Development training - Final assessment - UI Layer - Submitted by - Shanmugapriyan Vijayarangan, shanmvij@in.ibm.com, June 2019
==========================================================================================================================================
All the business requirements and use cases were implemented as provided in the requirements document, and the screenshots of the respective screens are captured and listed below.

1) The welcome page for any user ( login not required )                     -> HomeWelcomePage.png
2) The search results for a Guest user for a specific technology and timing -> GuestUserSearchResultsPage.png
3) Home page for an already signed-up Mentee                                -> RegisteredUserLoginPage.png
4) The new user sign-up page for a mentee                                   -> MenteeSignupPage.png
5) The new user sign-up page for a mentor                                   -> MentorSignupPage.png
6) Home page of a logged in user                                            -> LoggedInUserHomePage.png
7) Mentor notifications, current & completed trainings                      -> LoggedInMenteeOverallStatusPage.png
8) Home page of an already signed-up Mentor                                 -> LoggedInMentorHomePage.png
9) Trainings search results for a Mentee                                    -> LoggedInMenteeSearchResults.png
10) Home page of a logged in Administrator                                  -> LoggedInAdminUserHomePage.png
11) User administration page for Administrator                              -> AdminUserAdministrationPage.png
12) Mentor administration page for Administrator                            -> MentorAdministrationPage.png
13) Technology administration page fo Administrator                         -> AdminTechnologyAdministrationPage.png

Front-end technology used -> Angular
===================================
shanmugapriyan@oc4736408161 ~]$ ng --version

     _                      _                 ____ _     ___
    / \   _ __   __ _ _   _| | __ _ _ __     / ___| |   |_ _|
   / △ \ | '_ \ / _` | | | | |/ _` | '__|   | |   | |    | |
  / ___ \| | | | (_| | |_| | | (_| | |      | |___| |___ | |
 /_/   \_\_| |_|\__, |\__,_|_|\__,_|_|       \____|_____|___|
                |___/
    

Angular CLI: 7.3.5
Node: 8.11.1
OS: linux x64
Angular: 
... 

Package                      Version
------------------------------------------------------
@angular-devkit/architect    0.13.5
@angular-devkit/core         7.3.5
@angular-devkit/schematics   7.3.5
@schematics/angular          7.3.5
@schematics/update           0.13.5
rxjs                         6.3.3
typescript                   3.2.4
    
Editor used -> 'Visual Studio - Code
====================================

The project folder named 'mentorondemand' -> Can be opened using 'code' editor and the front-end can be run using 'npm install' followed by a 'ng-serve' command
========================================

Front-end URL         -> http://localhost:4200/welcome
Back-end (Server) URL -> url = 'http://localhost:8088/' ( hosted via. Eureka Microservices Server)
==================================================================================================
