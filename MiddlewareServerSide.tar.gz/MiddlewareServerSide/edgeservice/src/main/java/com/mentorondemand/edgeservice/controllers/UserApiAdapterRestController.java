package com.mentorondemand.edgeservice.controllers;

import java.util.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resources;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mentorondemand.edgeservice.client.UserClient;
import com.mentorondemand.edgeservice.dto.User;

@RestController
public class UserApiAdapterRestController {
	
	@Autowired
    private UserClient userClient;
	
    @GetMapping("/show")
    public Collection<User> AllUsers() {
    	Resources<User> readUsers = userClient.readUsers();
    	System.out.println(readUsers);
        return userClient.readUsers()
                .getContent();
    }
}