package com.mentorondemand.edgeservice.dto;

public class User {
	private Integer id;
	private String name;
	private String type;
	private String email;
	private String password;
	private Byte blocked;

	public User() {
		System.out.println("blank constructor");
	}

	public User(String name, String type, String email, String password, Byte blocked) {
		System.out.println("edgeservice User constructing");
		this.name = name;
		this.type = type;
		this.email = email;
		this.password = password;
		this.blocked = blocked;
	}

	public Integer getId() {
		System.out.println("edgeservice getId");		
		return this.id;
	}

	public void setId(Integer id) {
		System.out.println("edgeservice setId");
		this.id = id;
	}

	public String getName() {
		System.out.println("edgeservice getName");				
		return this.name;
	}

	public void setName(String name) {
		System.out.println("edgeservice setName");		
		this.name = name;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Byte getBlocked() {
		return this.blocked;
	}

	public void setBlocked(Byte blocked) {
		this.blocked = blocked;
	}

}
