package com.mentorondemand.edgeservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.hateoas.Resources;
import org.springframework.web.bind.annotation.GetMapping;

import com.mentorondemand.edgeservice.dto.User;

@FeignClient("user-service")  // creates a rest client
public interface UserClient {

    @GetMapping("/users")
    Resources<User> readUsers();
}