package com.mentorondemand.userservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Repository;

import com.mentorondemand.userservice.dto.Users;
import com.mentorondemand.userservice.dto.Timezone;
import com.mentorondemand.userservice.dto.MentorSkills;

import java.util.List;

@Repository
public interface UsersRepository extends JpaRepository<Users, Long> {
	public Users findByEmailAndPassword(String email, String pwd);
}