package com.mentorondemand.userservice.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.json.JSONObject;
import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.mentorondemand.userservice.dao.UsersRepository;
import com.mentorondemand.userservice.dto.Users;

import com.mentorondemand.userservice.dao.TrainingsRepository;
import com.mentorondemand.userservice.dto.Trainings;

import com.mentorondemand.userservice.dao.TechnologiesRepository;
import com.mentorondemand.userservice.dto.Technologies;

import com.mentorondemand.userservice.dao.TimezoneRepository;
import com.mentorondemand.userservice.dto.Timezone;

import com.mentorondemand.userservice.dao.UserViewRepository;
import com.mentorondemand.userservice.dto.Userview;
import com.mentorondemand.userservice.dto.UserviewId;

import com.mentorondemand.userservice.dao.MentorViewRepository;
import com.mentorondemand.userservice.dto.Mentorview;
import com.mentorondemand.userservice.dto.MentorviewId;
import com.mentorondemand.userservice.dao.AdminUserViewRepository;
import com.mentorondemand.userservice.dto.Adminuserview;
import com.mentorondemand.userservice.dto.AdminuserviewId;
import com.mentorondemand.userservice.dto.MentorCalendar;
import com.mentorondemand.userservice.dto.MentorSkills;
import com.mentorondemand.userservice.dto.MentorSkillsId;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.mentorondemand.userservice.dao.AdminMentorViewRepository;
import com.mentorondemand.userservice.dto.Adminmentorview;
import com.mentorondemand.userservice.dto.AdminmentorviewId;

@RestController
@CrossOrigin
public class UserServiceController {
    @PersistenceContext
    private EntityManager entityManager;
    
	@Autowired
	private UsersRepository usersRepository;

	@Autowired
	private TrainingsRepository trainingsRepository;

	@Autowired
	private TechnologiesRepository technologiesRepository;

	@Autowired
	private TimezoneRepository timezoneRepository;

	@Autowired
	private UserViewRepository userviewRepository;

	@Autowired
	private MentorViewRepository mentorviewRepository;

	@Autowired
	private AdminUserViewRepository adminuserviewRepository;

	@Autowired
	private AdminMentorViewRepository adminmentorviewRepository;

	@GetMapping("find-users")
	public List<Users> findAllUsers(){
		List<Users> Users = new ArrayList<>();
		usersRepository.findAll().forEach(Users::add);
		return Users;
	}

	@GetMapping("find-trainings")
	public List<Trainings> findAllTrainings(){
		List<Trainings> Trainings = new ArrayList<>();
		trainingsRepository.findAll().forEach(Trainings::add);
		return Trainings;
	}

	@GetMapping("find-technologies")
	public List<Technologies> findAllTechnologies(){
		List<Technologies> Technologies = new ArrayList<>();
		technologiesRepository.findAll().forEach(Technologies::add);
		return Technologies;
	}

	@GetMapping("find-timezones")
	public List<Timezone> findAllTimezones(){
		List<Timezone> TimeZones = new ArrayList<>();
		timezoneRepository.findAll().forEach(TimeZones::add);
		return TimeZones;
	}

	@GetMapping("find-history/{mentor}")
	public List<Mentorview> findMentorHistory(@PathVariable int mentor){
		List<Mentorview> Mentorview = new ArrayList<>();
		mentorviewRepository.findByIdMentor(mentor).forEach(Mentorview::add);
		return Mentorview;
	}
	
	@GetMapping("find-mentors/{technology}/{timezone}")
	public List<Userview> findUserviewByTechnologyAndTimezone(@PathVariable String technology,@PathVariable String timezone) {
		List<Userview> Userview = new ArrayList<>();
		userviewRepository.findByIdTechnologyAndIdTimezone(technology,timezone).forEach(Userview::add);
		return Userview;
	}
/*
	@GetMapping("find-mentors/{technology}/{timezone}/{hour}")
	public List<UserviewId> findUserview(@PathVariable String technology,@PathVariable String timezone, @PathVariable int hour) {
		List<UserviewId> UserviewId = new ArrayList<>();
		userviewRepository.findByIdTechnologyAndIdTimezoneAndIdWorkingfromLessThanEqualAndIdWorkingtillGreaterThanEqual(technology,timezone, hour, hour).forEach(e -> UserviewId.add(e.getId()));
		return UserviewId;
	}
	
	@GetMapping("find-mentors/{technology}/{timezone}/{hour}")
	public List<UserviewId> findUserview(@PathVariable String technology,@PathVariable String timezone, @PathVariable int hour) {
		List<UserviewId> UserviewId = new ArrayList<>();
		List<Integer> mentees = Arrays.asList(new Integer[]{0});
		userviewRepository.findByIdMenteeInAndIdTechnologyAndIdTimezoneAndIdWorkingfromLessThanEqualAndIdWorkingtillGreaterThanEqual(mentees, technology,timezone, hour, hour).forEach(e -> UserviewId.add(e.getId()));
		return UserviewId;
	}
	
	@GetMapping("find-mentors/{mentee}/{technology}/{timezone}/{hour}")
	public List<UserviewId> findUserview(@PathVariable int mentee, @PathVariable String technology,@PathVariable String timezone, @PathVariable int hour) {
		List<UserviewId> UserviewId = new ArrayList<>();
		List<Integer> mentees = Arrays.asList(new Integer[]{0, mentee});
		userviewRepository.findByIdMenteeInAndIdTechnologyAndIdTimezoneAndIdWorkingfromLessThanEqualAndIdWorkingtillGreaterThanEqual(mentees, technology,timezone, hour, hour).forEach(e -> UserviewId.add(e.getId()));
		return UserviewId;
	}
*/
	@GetMapping("find-mentors/{technology}/{timezone}/{hour}")
	public List<UserviewId> findUserview(@PathVariable String technology,@PathVariable String timezone, @PathVariable int hour) {
		List<UserviewId> UserviewId = new ArrayList<>();
		userviewRepository.findByIdTechnologyAndIdTimezoneAndIdWorkingfromLessThanEqualAndIdWorkingtillGreaterThanEqual(technology,timezone, hour, hour).forEach(e -> UserviewId.add(e.getId()));
		return UserviewId;
	}
	
	@GetMapping("find-mentors/{mentee}/{technology}/{timezone}/{hour}")
	public List<UserviewId> findUserview(@PathVariable long mentee, @PathVariable String technology,@PathVariable String timezone, @PathVariable int hour) {
		List<UserviewId> UserviewId = new ArrayList<>();
		List<Long> mentees = Arrays.asList(new Long[]{(long) 0, mentee});
		userviewRepository.findByIdMenteeInAndIdTechnologyAndIdTimezoneAndIdWorkingfromLessThanEqualAndIdWorkingtillGreaterThanEqual(mentees, technology,timezone, hour, hour).forEach(e -> UserviewId.add(e.getId()));
		return UserviewId;
	}

	@GetMapping("find-mentee/{mentee}")
	public List<UserviewId> findByIdMentee(@PathVariable long mentee) {
		List<UserviewId> UserviewId = new ArrayList<>();
		userviewRepository.findByIdMentee(new Long(mentee)).forEach(e -> UserviewId.add(e.getId()));
		return UserviewId;
	}
	
	@GetMapping("authenticate/{email}/{pwd}")
	public Users findUser(@PathVariable String email, @PathVariable String pwd) {
		Users user = new Users();
		user = usersRepository.findByEmailAndPassword(email, pwd);
		return user;
	}
	
	@GetMapping("admin-users")
	public List<AdminuserviewId> findAllUsersForAdmin() {
		List<AdminuserviewId> adminuserviewId = new ArrayList<>();
		adminuserviewRepository.findAll().forEach(e -> adminuserviewId.add(e.getId()));
		return adminuserviewId;
	}

	@GetMapping("admin-mentors")
	public List<AdminmentorviewId> findAllMentorsForAdmin() {
		List<AdminmentorviewId> adminmentorviewId = new ArrayList<>();
		adminmentorviewRepository.findAll().forEach(e -> adminmentorviewId.add(e.getId()));
		return adminmentorviewId;
	}

	@GetMapping("admin-tech")
	public List<Technologies> findAllTechnologiesForAdmin() {
		List<Technologies> techs = new ArrayList<>();
		technologiesRepository.findAll().forEach(techs::add);
		return techs;
	}
	
	@Transactional
	@RequestMapping(value = "/propose", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public void proposefortraining(@RequestBody Trainings training) {
		this.entityManager.persist(training); // Mentee proposes for a training
		this.entityManager.flush();
	}

	@Transactional
	@RequestMapping(value = "/confirm", method = RequestMethod.PUT, consumes = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public void confirmTraining(@RequestBody Trainings training) {
		Trainings confirm = (Trainings)this.entityManager.find(Trainings.class,training.getId());
		confirm.setStatus(1); // Mentor Confirms training
	}

	@Transactional
	@RequestMapping(value = "/finalize", method = RequestMethod.PUT, consumes = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public void finalizeTraining(@RequestBody Trainings training) {
		Trainings finalize = (Trainings)this.entityManager.find(Trainings.class,training.getId());
		finalize.setFinalized((byte) 1); // Mentee finalizes training
	}
	
	@Transactional
	@RequestMapping(value = "/reject", method = RequestMethod.PUT, consumes = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public void rejectTraining(@RequestBody Trainings training) {
		Trainings reject = (Trainings)this.entityManager.find(Trainings.class,training.getId());
		reject.setStatus(-1); // Mentor rejects training
	}

	@Transactional
	@RequestMapping(value = "/progress", method = RequestMethod.PUT, consumes = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public void progress(@RequestBody Trainings training) {
		Trainings report = (Trainings)this.entityManager.find(Trainings.class,training.getId());
		MentorSkills skills = (MentorSkills)this.entityManager.find(MentorSkills.class, new MentorSkillsId(training.getId().getMentor(), training.getId().getTechnology()));
		Integer prevprog = report.getProgress();
		Integer currentprog = training.getProgress();
		report.setProgress(training.getProgress()); // Mentee reports progress
		double prevpayment = report.getMentorSkills().getCost() * prevprog / 100;
	    double currentpayment = report.getMentorSkills().getCost() * currentprog / 100;
		skills.setPayment(skills.getPayment() - prevpayment + currentpayment );
	}

	@Transactional
	@RequestMapping(value = "/rate", method = RequestMethod.PUT, consumes = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public void rate(@RequestBody Trainings training) {
		Trainings report = (Trainings)this.entityManager.find(Trainings.class,training.getId());
		report.setRate(training.getRate()); // Mentee rates a training
//		this.entityManager.flush();		
	}

	@Transactional
	@RequestMapping(value = "/admin-users-block", method = RequestMethod.PUT, consumes = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public void block(@RequestBody Users user) {
		Users block = (Users)this.entityManager.find(Users.class,user.getId());
		block.setBlocked((byte) 1);
	}
	
	@Transactional
	@RequestMapping(value = "/admin-users-unblock", method = RequestMethod.PUT, consumes = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public void unblock(@RequestBody Users user) {
		Users unblock = (Users)this.entityManager.find(Users.class,user.getId());
		unblock.setBlocked((byte) 0);
	}
	
	@Transactional
	@RequestMapping(value = "/commission", method = RequestMethod.PUT, consumes = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public void commssion(@RequestBody MentorSkills mentor) {
		MentorSkills skills = this.entityManager.find(MentorSkills.class,mentor.getId());
		skills.setCommission(mentor.getCommission());
	}
	
	@Transactional
	@RequestMapping(value = "/add-tech", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public Technologies addTechnology(@RequestBody Technologies technology) {
		this.entityManager.persist(technology); // Add new technology
		this.entityManager.flush(); // Works even without a 'flush'
		return technology;
	}
	
	@Transactional
	@RequestMapping(value = "/toggle-tech", method = RequestMethod.PUT, consumes = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public void toggletechnology(@RequestBody Technologies tech) {
	    Technologies toggle = (Technologies)this.entityManager.find(Technologies.class, tech.getTechnology());
    	toggle.setActive((byte) ((toggle.getActive() ==  (byte) 1)? 0: 1));
	}

	@Transactional
	@RequestMapping(value = "/add-user", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public void addUser(@RequestBody Users user) {
		this.entityManager.persist(user); // Add new technology
		this.entityManager.flush(); // Works even without a 'flush'
	}

	@Transactional
	@RequestMapping(value = "/add-mentor", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public void addMentor(@RequestBody Object mentor) {
//		if (mentor instanceof Map) System.out.println("Yes mentor instance of Map");
		//Write JSON from java objects
		ObjectMapper mapper = new ObjectMapper();
		JSONObject jsonobj = null;
		try {
//			System.out.println(mapper.writeValueAsString(mentor));
			jsonobj = new JSONObject(mapper.writeValueAsString(mentor));
        } 
        catch (IOException e) { 
            e.printStackTrace(); 
        } 		
		JSONObject userobj = jsonobj.getJSONObject("User");
		JSONObject calendarobj = jsonobj.getJSONObject("Calendar");
		JSONArray mentorarray =  jsonobj.getJSONArray("Mentor"); 
		Gson gson = new Gson();
		Users user = gson.fromJson(userobj.toString(),Users.class);
		this.entityManager.persist(user);
		Users founduser = null;
    	founduser = usersRepository.findByEmailAndPassword(user.getEmail(), user.getPassword());
		MentorCalendar calendar = gson.fromJson(calendarobj.toString(),MentorCalendar.class);
		calendar.setUsers(founduser);
		this.entityManager.persist(calendar);
		MentorSkills mentorobj = null;
		for (int i = 0; i < mentorarray.length(); i++) {
			mentorobj = gson.fromJson(mentorarray.get(i).toString(),MentorSkills.class);
			 if (mentorobj.getCost() > 0) {
				 mentorobj.setUsers(founduser);
				 this.entityManager.persist(mentorobj);
			 }
		}
		//this.entityManager.flush(); // Works even without a 'flush'
	}
}