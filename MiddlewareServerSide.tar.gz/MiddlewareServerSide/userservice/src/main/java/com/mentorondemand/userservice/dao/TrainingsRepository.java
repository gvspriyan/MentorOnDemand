package com.mentorondemand.userservice.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Repository;

import com.mentorondemand.userservice.dto.Trainings;
import com.mentorondemand.userservice.dto.Userview;

@Repository
public interface TrainingsRepository extends JpaRepository<Trainings, Long> {}