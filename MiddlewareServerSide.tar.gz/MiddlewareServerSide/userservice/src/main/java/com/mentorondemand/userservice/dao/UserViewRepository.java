package com.mentorondemand.userservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.mentorondemand.userservice.dto.Userview;
import com.mentorondemand.userservice.dto.Trainings;
import com.mentorondemand.userservice.dto.Users;

import java.util.Collection;
import java.util.List;

@Repository
public interface UserViewRepository extends JpaRepository<Userview, Long> {
	public List<Userview> findByIdTechnologyAndIdTimezone(String technology, String timezone);
	public List<Userview> findByIdTechnologyAndIdTimezoneAndIdWorkingfromLessThanEqualAndIdWorkingtillGreaterThanEqual(String technology, String timezone, int lthour, int gthour);
	public List<Userview> findByIdMenteeInAndIdTechnologyAndIdTimezoneAndIdWorkingfromLessThanEqualAndIdWorkingtillGreaterThanEqual(List<Long> mentee, String technology, String timezone, int lthour, int gthour);
	public List<Userview> findByIdMentor(int mentor);
	public List<Userview> findByIdMentee(Long mentee);	
}