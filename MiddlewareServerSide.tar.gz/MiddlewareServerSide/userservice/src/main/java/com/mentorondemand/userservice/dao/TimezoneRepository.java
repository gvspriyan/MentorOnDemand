package com.mentorondemand.userservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.mentorondemand.userservice.dto.Timezone;

@Repository
public interface TimezoneRepository extends JpaRepository<Timezone, Long> {}	
