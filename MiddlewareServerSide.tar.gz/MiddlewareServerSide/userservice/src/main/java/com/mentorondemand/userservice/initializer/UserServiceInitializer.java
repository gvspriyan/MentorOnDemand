package com.mentorondemand.userservice.initializer;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.mentorondemand.userservice.dao.UsersRepository;
import com.mentorondemand.userservice.dao.TrainingsRepository;

@Component
public class UserServiceInitializer implements CommandLineRunner {

    private final UsersRepository usersRepository;
    private final TrainingsRepository trainingsRepository;
  
    
    UserServiceInitializer(UsersRepository usersRepository,TrainingsRepository trainingsRepository) {
        this.usersRepository = usersRepository;
        this.trainingsRepository = trainingsRepository;        
    }
    
    @Override
    public void run(String... args) throws Exception {
    }
}
