package com.mentorondemand.userservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.mentorondemand.userservice.dto.Mentorview;
import java.util.List;

@Repository
public interface MentorViewRepository extends JpaRepository<Mentorview, Long> {
	public List<Mentorview> findByIdMentor(int mentor);
}