Full Stack Development training - Final assessment - Middleware Server Side - Submitted by - Shanmugapriyan Vijayarangan, shanmvij@in.ibm.com, June 2019
========================================================================================================================================================
The middleware layer for this assignment consist of the following servers/services. All were build using spring framework ( https://start.spring.io/ ) and all
these are 'Maven' projects with their dependencies listed in their respective 'pom.xml' file
1) The Eureka server -> spring-cloud-netflix Eureka Server
2) The Edger service  -> Eureka discovery client that is also built with Hysterix & Zulu for load balancing
3) The User (micro) Service -> Eureka discovery client, with Hibernate & JPA to interact with the database

The Eureka server screenshot showing availability of both the 'Edge service' as well as the 'User microserice' is shown in the screenshot -> EurekaServerScreenshot.png
The pom.xml of the server & services will give clarities on the dependent libraries used.
Eclipse editor was used to build these server & services. Screenshot of the same is -> EclipseEditorScreenshot.png

Technologies used
=================
1) Eclise editor
2) Maven -> https://mvnrepository.com/
3) Spring boot -> https://start.spring.io/


