-- MySQL Workbench Synchronization
-- Generated: 2019-06-26 19:45
-- Model: New Model
-- Version: 1.0
-- Project: Name of the project
-- Author: Shanmugapriyan

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

ALTER TABLE `mydb`.`MentorSkills` 
DROP FOREIGN KEY `fk_MentorSkills_1`,
DROP FOREIGN KEY `fk_MentorSkills_2`,
DROP FOREIGN KEY `FKox8nxal7bgt4tb8sm1h6yovkq`,
DROP FOREIGN KEY `FK1up2nyisbtxerudokpfp4m8tk`;

ALTER TABLE `mydb`.`Trainings` 
DROP FOREIGN KEY `fk_Proposals_1`,
DROP FOREIGN KEY `fk_Proposals_2`,
DROP FOREIGN KEY `FKf0endg6eq5m13l5l3ycyji6qq`,
DROP FOREIGN KEY `FK6o4pvf5c9wkll4a72gcuq5249`;

ALTER TABLE `mydb`.`MentorCalendar` 
DROP FOREIGN KEY `fk_MentorCalendar_1`;

ALTER TABLE `mydb`.`Users` 
CHANGE COLUMN `blocked` `blocked` TINYINT(4) NULL DEFAULT NULL COMMENT 'Block or Unblock User or Mentor\n' ,
DROP INDEX `UKncoa9bfasrql0x4nhmh1plxxy` ;
;

ALTER TABLE `mydb`.`Trainings` 
CHANGE COLUMN `status` `status` INT(11) NULL DEFAULT NULL COMMENT 'status signifies whether the trainer confirms or rejects the proposal (0 -> proposed, 1 -> confirmed, -1 -> rejected )\n' ,
CHANGE COLUMN `finalized` `finalized` TINYINT(4) NULL DEFAULT NULL COMMENT 'finalized signifies whether the user finalized a confirmed proposal response\n' ,
CHANGE COLUMN `progress` `progress` INT(11) NULL DEFAULT NULL COMMENT 'Actual progress need to be updated by User and it is a percentage ( 0 <> 100). A training can be considered as \'in-progress\' if \'finalized\' is true and \'progress\' between 0 and 100.\nSimilarly a training can be considered as \'complete\' if \'finalized\' is true and \'progress\' is 100.' ,
CHANGE COLUMN `starts_at` `starts_at` INT(11) NULL DEFAULT NULL COMMENT 'starting time ( 24 hours format )\n\n' ,
CHANGE COLUMN `ends_at` `ends_at` INT(11) NULL DEFAULT NULL COMMENT 'end time (24 hours format)\n' ;

ALTER TABLE `mydb`.`MentorSkills` 
ADD CONSTRAINT `fk_MentorSkills_1`
  FOREIGN KEY (`mentor`)
  REFERENCES `mydb`.`Users` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_MentorSkills_2`
  FOREIGN KEY (`technology`)
  REFERENCES `mydb`.`Technologies` (`technology`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE `mydb`.`Trainings` 
ADD CONSTRAINT `fk_Proposals_1`
  FOREIGN KEY (`mentor` , `technology`)
  REFERENCES `mydb`.`MentorSkills` (`mentor` , `technology`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_Proposals_2`
  FOREIGN KEY (`mentee`)
  REFERENCES `mydb`.`Users` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE `mydb`.`MentorCalendar` 
ADD CONSTRAINT `fk_MentorCalendar_1`
  FOREIGN KEY (`mentor`)
  REFERENCES `mydb`.`Users` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;


-- -----------------------------------------------------
-- Placeholder table for view `mydb`.`timezone`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`timezone` (`TIMEZONE` INT);

-- -----------------------------------------------------
-- Placeholder table for view `mydb`.`userview`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`userview` (`mentor` INT, `name` INT, `mentee` INT, `technology` INT, `yearsofexperience` INT, `nooftrainingsdelivered` INT, `rate` INT, `progress` INT, `feecharged` INT, `timezone` INT, `workingfrom` INT, `workingtill` INT, `status` INT);

-- -----------------------------------------------------
-- Placeholder table for view `mydb`.`mentorview`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`mentorview` (`mentor` INT, `mentee` INT, `name` INT, `technology` INT, `rate` INT, `starts_at` INT, `ends_at` INT, `status` INT);

-- -----------------------------------------------------
-- Placeholder table for view `mydb`.`adminuserview`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`adminuserview` (`id` INT, `name` INT, `type` INT, `email` INT, `blocked` INT);

-- -----------------------------------------------------
-- Placeholder table for view `mydb`.`adminmentorview`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`adminmentorview` (`mentor` INT, `name` INT, `type` INT, `email` INT, `blocked` INT, `technology` INT, `cost` INT, `commission` INT, `payment` INT);


USE `mydb`;

-- -----------------------------------------------------
-- View `mydb`.`timezone`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `mydb`.`timezone`;
USE `mydb`;
CREATE  OR REPLACE VIEW `timezone` AS SELECT DISTINCT TIMEZONE FROM MentorCalendar;


USE `mydb`;

-- -----------------------------------------------------
-- View `mydb`.`userview`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `mydb`.`userview`;
USE `mydb`;
CREATE  OR REPLACE VIEW `userview` AS select u.id as mentor, u.name, IF(t.mentee is null,0,t.mentee) as mentee, m.technology, yearsofexperience, nooftrainingsdelivered, IF(rate is null,0,rate) as rate, IF(progress is null,0, progress) as progress, format(cost + cost * commission/100,2) as feecharged, timezone, workingfrom, workingtill, CASE WHEN progress >= 100 THEN "COMPLETED" WHEN status is null THEN "NONE" WHEN status = 0 THEN "PROPOSED" WHEN status = 1 THEN IF(finalized = 0, "CONFIRMED", "FINALIZED") WHEN status = -1 THEN "REJECTED" ELSE "UNEXPECTED" END as status from mydb.MentorSkills m inner join mydb.Users u on (u.id = m.mentor) inner join mydb.MentorCalendar c on (m.mentor = c.mentor) left join mydb.Trainings t on (m.mentor = t.mentor and m.technology = t.technology);


USE `mydb`;

-- -----------------------------------------------------
-- View `mydb`.`mentorview`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `mydb`.`mentorview`;
USE `mydb`;
CREATE  OR REPLACE VIEW `mentorview` AS select mentor, mentee, u.name, technology, rate, starts_at, ends_at, CASE WHEN status is null THEN "NONE" WHEN status = 0 THEN "PROPOSED" WHEN status = 1 THEN IF(finalized = 0, "CONFIRMED", "FINALIZED") WHEN status = -1 THEN "REJECTED" ELSE "UNEXPECTED" END as status from mydb.Trainings t inner join mydb.Users u on (u.id = t.mentee);


USE `mydb`;

-- -----------------------------------------------------
-- View `mydb`.`adminuserview`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `mydb`.`adminuserview`;
USE `mydb`;
CREATE OR REPLACE VIEW `adminuserview` AS select id, name, type, email, blocked from mydb.Users;


USE `mydb`;

-- -----------------------------------------------------
-- View `mydb`.`adminmentorview`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `mydb`.`adminmentorview`;
USE `mydb`;
CREATE OR REPLACE VIEW `adminmentorview` AS select mentor, name, type, email, blocked, technology, cost, commission, IF(payment is null, 0, payment) as payment from mydb.Users u left join mydb.MentorSkills s on u.id = s.mentor where type = 'mentor';

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
