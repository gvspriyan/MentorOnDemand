Full Stack Development training - Final assessment - Database Connectivity Integration - Submitted by - Shanmugapriyan Vijayarangan, shanmvij@in.ibm.com, June 2019
===================================================================================================================================================================
The database was built upon mysql and Eureka discovery client with Hibernate and JPA was used to establish connectivity with mysql for entity object generation

mysql> select version();
+-----------+
| version() |
+-----------+
| 8.0.16    |
+-----------+
1 row in set (0.01 sec)

Mock data generation was done using -> https://mockaroo.com/ and the .csv mock data generated for this project are uploaded as well.

The following four tables were created for this assignment
1) Users
2) Technologies
3) Trainings
4) MentorSkills
5) MentorCalendar

The following views were created to support fetching data for the front-end
1) adminmentorview
2) adminuserview
3) mentorview
4) timezone
5) userview

'MySQL Workbench' tool was used to design as well as create the database
=========================================================================
mysql> show databases;
+--------------------+
| Database           |
+--------------------+
| information_schema |
| mydb               |
| mysql              |
| performance_schema |
| sys                |
+--------------------+
5 rows in set (0.10 sec)

mysql> use mydb;
Reading table information for completion of table and column names
You can turn off this feature to get a quicker startup with -A

Database changed
mysql> show tables;
+-----------------+
| Tables_in_mydb  |
+-----------------+
| MentorCalendar  |
| MentorSkills    |
| Technologies    |
| Trainings       |
| Users           |
| adminmentorview |
| adminuserview   |
| mentorview      |
| timezone        |
| userview        |
+-----------------+
10 rows in set (0.01 sec)

mysql> 

The sql script file 'mentorondemand.sql' was auto-generated from 'MySQL Workbench' and the same was used to create the database
================================================================================================================================


